﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace WebApplication5.Models
{
    public class ApplicationUser: IdentityUser
    {
        [Display(Name = "UserName")]
        public string UserName { get; set; }
        public string Test { get; set; }

    }
}
