﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication5.Utility
{
    public class StaticDetails
    {
        public const string AdminRole = "Admin";
        public const string LearnerRole = "Learner";
    }
}
