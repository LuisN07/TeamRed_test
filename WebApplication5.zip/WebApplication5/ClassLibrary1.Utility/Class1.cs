﻿using System;

namespace WebApplication5.Utility
{
    public class Class1
    {
    }
}
