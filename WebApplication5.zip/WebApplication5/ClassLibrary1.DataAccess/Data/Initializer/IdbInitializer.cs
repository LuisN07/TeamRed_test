﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication5.DataAccess.Data.Initializer
{
    public interface IdbInitializer
    {
        void Initialize();
    }
}
