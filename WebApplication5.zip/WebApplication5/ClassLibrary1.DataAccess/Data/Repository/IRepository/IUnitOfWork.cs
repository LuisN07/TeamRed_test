﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication5.DataAccess.Data.Repository.IRepository
{
    public interface IUnitOfWork: IDisposable
    {
        ICategoryRepository Category { get; }
        ICategoryRequestRepository CategoryRequest { get; }
        IApplicationUserRepository ApplicationUser { get; }
        void Save();

    }
}
