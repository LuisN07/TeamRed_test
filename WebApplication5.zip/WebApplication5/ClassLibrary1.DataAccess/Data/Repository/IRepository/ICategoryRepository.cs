﻿using System;
using System.Collections.Generic;
using System.Text;
using WebApplication5.Models;

namespace WebApplication5.DataAccess.Data.Repository.IRepository
{
    public interface ICategoryRepository : IRepository<Category>
    {
        void Update(Category category);
    }
}
