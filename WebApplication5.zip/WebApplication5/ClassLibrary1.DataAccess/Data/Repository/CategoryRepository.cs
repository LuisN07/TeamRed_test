﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebApplication5.DataAccess.Data.Repository.IRepository;
using WebApplication5.Models;

namespace WebApplication5.DataAccess.Data.Repository
{
    public class CategoryRepository: Repository<Category>, ICategoryRepository
    {
        private readonly ApplicationDbContext _db;

        public CategoryRepository(ApplicationDbContext db): base(db)
        {
            _db = db;
        }

        public void Update(Category category)
        {
            var objFromDb = _db.Category.FirstOrDefault(s => s.Id == category.Id);

            objFromDb.Name = category.Name;
            objFromDb.Content = category.Content;

            _db.SaveChanges();
        }
    }
}
