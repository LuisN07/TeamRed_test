﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication5.DataAccess.Migrations
{
    public partial class AddCategoryRequest : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
